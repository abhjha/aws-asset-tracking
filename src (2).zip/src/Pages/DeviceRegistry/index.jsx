import React from 'react';
import ComingSoon from '../ComingSoon/index'


import './index.css';
class DeviceRegistry extends React.Component {
    render(){
        return (
        <div>
           <ComingSoon label={'Device Registry'} />
        </div>);
    }
}

export default DeviceRegistry;