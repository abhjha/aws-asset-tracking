import React from 'react';
import ComingSoon from '../ComingSoon/index'


import './index.css';
class EditAsset extends React.Component {
    render(){
        return (
        <div>
           <ComingSoon label={'Edit Asset'} />
        </div>);
    }
}

export default EditAsset;